# tenant_users

This is not a orignial repo.I just made some changes into repo according to my requirements original repo link is https://github.com/Corvia/django-tenant-users
